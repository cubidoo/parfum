chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log(request);

    if (request.message === "waitForATC") {

        chrome.webRequest.onCompleted.addListener(
            function check(details) {
                if (details.url.includes(".parfumdreams") && details.url.includes("/Order/AddVariation")) {
                    chrome.webRequest.onCompleted.removeListener(check);
                    console.log(details);

                    if (details.statusCode == 200 || details.statusCode == 204) {
                        setTimeout(() => {
                            sendResponse("success");
                        }, 1000);
                    } else sendResponse("failed");
                    return true;
                }
            }, {
                urls: ["<all_urls>"]
            }
        );
        return true;
    } else if (request.message === "deleteCookies") {
        chrome.cookies.getAll({
            domain: ".parfumdreams.de"
        }, function (cookies) {
            for (var i = 0; i < cookies.length; i++) {
                chrome.cookies.remove({
                    url: "https://" + cookies[i].domain + cookies[i].path,
                    name: cookies[i].name
                });
            }
            sendResponse("success");
        });
        return true;
    }
});