var url = document.location;

if (url.origin.includes("parfumdreams") && url.href.includes("/Order/")) {

    chrome.storage.local.get([
        "valid",
        "paymentmethod",
        "ccnumber",
        "cccvv",
        "ccmonth",
        "ccyear"
    ], (a) => {
        if (a.valid) {
            console.log("Logged in!");

            //wait for document load
            if (document.readyState !== 'loading') {
                start();
            } else {
                document.addEventListener('DOMContentLoaded', function () {
                    start();
                });
            }

            function start() {
                if (document.querySelector('[id="payment_Kreditkarte"]')) { //already loaded
                    if (a.paymentmethod === 'cc') {
                        console.log("CC Fill");
                        ccfill();
                    } else {
                        console.log("Paypal");
                        paypal();
                    }
                } else {
                    //wait for email to load
                    const fe = new MutationObserver(mutations => {
                        if (document.querySelector('[id="payment_Kreditkarte"]')) {
                            if (a.paymentmethod === 'cc') {
                                console.log("CC Fill");
                                ccfill();
                            } else {
                                console.log("Paypal");
                                paypal();
                            }

                            fe.disconnect();
                        }
                    });
                    fe.observe(document.body, {
                        childList: true,
                        subtree: true
                    });
                }
            }

            function paypal() {
                document.querySelector('[id="payment_PayPal"]').click();
                setTimeout(() => {
                    document.querySelector('[id="payment-paypal-submit"]').click();
                }, 2000);
            }

            function ccfill() {

                document.querySelector('[id="payment_Kreditkarte"]').click();

                document.querySelector('[id="cardnumber"]').focus();
                document.querySelector('[id="cardnumber"]').value = a.ccnumber;
                document.querySelector('[id="cardnumber"]').blur();

                document.querySelector('[id="cvm"]').focus();
                document.querySelector('[id="cvm"]').value = a.cccvv;
                document.querySelector('[id="cvm"]').blur();

                document.querySelector('[id="expmonth"]').focus();
                document.querySelector('[id="expmonth"]').value = a.ccmonth;
                document.querySelector('[id="expmonth"]').blur();

                document.querySelector('[id="expyear"]').focus();
                document.querySelector('[id="expyear"]').value = a.ccyear;
                document.querySelector('[id="expyear"]').blur();

                document.querySelector('[id="cardnumber"]').dispatchEvent(new Event('change'));
                document.querySelector('[id="cvm"]').dispatchEvent(new Event('change'));
                document.querySelector('[id="expmonth"]').dispatchEvent(new Event('change'));
                document.querySelector('[id="expyear"]').dispatchEvent(new Event('change'));

                setTimeout(() => {
                    document.querySelector('[id="payment-telecash-submit"]').getElementsByTagName('button')[0].click();
                }, 2000);

            }
        }
    });
}