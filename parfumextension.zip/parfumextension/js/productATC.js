var url = document.location;

if (url.origin.includes("parfumdreams") && url.href.includes(".aspx")) {
    chrome.storage.local.get([
        "valid",
        "dummyProfile",
        "invoiceProfiles",
        "coupons"
    ], (a) => {
        if (a.valid) {
            console.log("Logged in!");
            var params = new URLSearchParams(url.search);
            console.log(params);

            var user;
            console.log(a.dummyProfile);
            console.log(a.invoiceProfiles);

            //Get random Invoice ID
            var invoiceProfile = a.invoiceProfiles[Math.floor(Math.random() * a.invoiceProfiles.length)];
            var invoiceID = invoiceProfile.id;
            console.log(invoiceProfile);

            //shipping info
            var firstname = "";
            var lastname = "";
            var fullname;
            var fullstreet;
            var street = "";
            var housenumber = "";
            var street2 = "";
            var fullcity;
            var plz = "";
            var city = "";

            //wait for document load
            if (document.readyState !== 'loading') {
                start();
            } else {
                document.addEventListener('DOMContentLoaded', function () {
                    start();
                });
            }

            function start() {
                user = JSON.parse(localStorage.User);

                //add checkout button
                var checkoutbtn = document.createElement("button");
                checkoutbtn.innerHTML = 'CHECKOUT';
                checkoutbtn.style.width = '100px';
                checkoutbtn.style.height = '50px';
                checkoutbtn.id = 'checkoutbtn';
                document.querySelector('[id="addToCart"]').parentNode.appendChild(checkoutbtn);

                document.getElementById("checkoutbtn").addEventListener("click", () => {
                    checkout();
                });

                //no parameters - wait for ATC, then start checkout
                if (params.size == 0) {
                    try {
                        iziToast.info({
                            title: "Cart Product to continue.",
                            message: "No Amazon Link. Starting Default Mode."
                        });
                    } catch {}

                    chrome.runtime.sendMessage({
                        message: 'waitForATC'
                    }, function (response) {
                        console.log(response);

                        if (response === "success") {
                            getShippingInfo();
                        }
                    });
                }
                //checkout + shipping -> wait for ATC, then start checkout
                else if (params.get("checkout") === "true" && params.get("shipping") === "true") {
                    try {
                        iziToast.info({
                            title: "Cart Product to continue.",
                            message: "Shipping Info found."
                        });
                    } catch {}

                    chrome.runtime.sendMessage({
                        message: 'waitForATC'
                    }, function (response) {
                        console.log(response);
                        if (response === "success") {
                            try {
                                firstname = params.get("firstname");
                                lastname = params.get("lastname");
                                street = params.get("street");
                                housenumber = params.get("housenumber");
                                street2 = params.get("street2");
                                plz = params.get("plz");
                                city = params.get("city");

                                editClientProfile();
                            } catch (error) {
                                try {
                                    iziToast.error({
                                        title: "Invalid Address.",
                                        message: error.message
                                    });
                                } catch {}
                            }
                        };
                    });
                }
                //checkout + no shipping -> wait for ATC, then ask for shipping info for checkout
                else if (params.get("checkout") === "true" && params.get("shipping") === "false") {
                    try {
                        iziToast.info({
                            title: "Cart Product to continue."
                        });
                    } catch {}

                    chrome.runtime.sendMessage({
                        message: 'waitForATC'
                    }, function (response) {
                        console.log(response);

                        if (response === "success") {
                            getShippingInfo();
                        }
                    });
                }
                //no checkout + shipping -> wait for Checkout
                else if (params.get("checkout") === "false" && params.get("shipping") === "true") {
                    try {
                        iziToast.info({
                            title: "Waiting for Checkout.",
                            message: "Shipping Info found."
                        });
                    } catch {}
                }
                //no checkout + no shipping -> wait for Checkout, then ask for shipping info for checkout
                else if (params.get("checkout") === "false" && params.get("shipping") === "false") {
                    try {
                        iziToast.info({
                            title: "Waiting for Checkout."
                        });
                    } catch {}
                }
            }

            function checkout() {
                //checkout with shipping
                if (params.get("shipping") === "true") {
                    try {
                        firstname = params.get("firstname");
                        lastname = params.get("lastname");
                        street = params.get("street");
                        housenumber = params.get("housenumber");
                        street2 = params.get("street2");
                        plz = params.get("plz");
                        city = params.get("city");

                        editClientProfile();
                    } catch (error) {
                        try {
                            iziToast.error({
                                title: "Invalid Address.",
                                message: error.message
                            });
                        } catch {}
                    }
                }
                //ask for shipping, then checkout
                else if (params.get("shipping") === "false") {
                    getShippingInfo();
                } else {
                    getShippingInfo();
                }
            }

            function getShippingInfo() {
                let textInput = prompt("Shipping Addy:", "").replaceAll('\r', '');
                textInput = textInput.replace(',\nDeutschland', "");

                var shippingInfos = textInput.split('\n');
                console.log(shippingInfos);

                //shipping information
                fullname = shippingInfos[0].split(" ");

                if (shippingInfos.length == 3) { //without address2
                    fullstreet = shippingInfos[1].split(" ");
                    fullcity = shippingInfos[2].split(" ");

                    //Full Name
                    lastname = fullname[fullname.length - 1];
                    fullname.pop(); //remove last word
                    firstname = fullname.join(' ');

                    //Street
                    housenumber = fullstreet[fullstreet.length - 1];
                    fullstreet.pop(); //remove last word
                    street = fullstreet.join(' ');

                    //PLZ
                    plz = fullcity[0];
                    fullcity.shift(); //remove first word
                    city = fullcity.join(' ');

                    city = city.replace(',', "");
                    editClientProfile();
                } else if (shippingInfos.length == 4) { //with address2
                    fullstreet = shippingInfos[2].split(" ");
                    fullcity = shippingInfos[3].split(" ");

                    //Full Name
                    lastname = fullname[fullname.length - 1];
                    fullname.pop(); //remove last word
                    firstname = fullname.join(' ');

                    //Street
                    housenumber = fullstreet[fullstreet.length - 1];
                    fullstreet.pop(); //remove last word
                    street = fullstreet.join(' ');

                    street2 = shippingInfos[1];

                    //PLZ
                    plz = fullcity[0];
                    fullcity.shift(); //remove first word
                    city = fullcity.join(' ');

                    city = city.replace(',', "");
                    editClientProfile();
                } else {
                    try {
                        iziToast.error({
                            title: "Invalid Address."
                        });
                    } catch {}
                }
            }

            function editClientProfile() {
                console.log(firstname);
                console.log(lastname);
                console.log(street2);
                console.log(street);
                console.log(housenumber);
                console.log(plz);
                console.log(city);

                //Edit Client Shipping Profile
                try {
                    iziToast.info({
                        title: "Submitting Client Info. (1/2)"
                    });
                } catch {}

                var body = {
                    "address": {
                        "$type": "DefaultAddressViewModel",
                        "addition": `${street2}`,
                        "street": `${street}`,
                        "houseNumberIsRequired": true,
                        "houseNumber": `${housenumber}`,
                        "type": 1,
                        "compactFormat": `${firstname} ${lastname}\n${street} ${housenumber}, ${plz} ${city}, de`,
                        "defaultFormat": `${street} ${housenumber}\n${plz} ${city}\nDeutschland`,
                        "streetAndHouseNumber": `${street} ${housenumber}`,
                        "id": `${a.dummyProfile.id}`,
                        "name": `${lastname}`,
                        "forenameIsRequired": true,
                        "forename": `${firstname}`,
                        "postCode": `${plz}`,
                        "city": `${city}`,
                        "countryToken": "de",
                        "country": "Deutschland",
                        "phone": "",
                        "isDefaultShippingAddress": true
                    }
                }

                fetch(`https://shop-api.parfumdreams.de/api/DE/user/updateaddress?userId=${user.userId}`, {
                    "headers": {
                        "accept": "*/*",
                        "accept-language": "de,en-US;q=0.9,en;q=0.8,de-DE;q=0.7",
                        "api-client-app-ctx.is-apple": "False",
                        "api-client-app-ctx.remote-ip-address": "10.15.0.252",
                        "api-client-app-ctx.view-mode": "1",
                        "api-key": "",
                        "authorization": `Bearer ${user.accessToken}`,
                        "content-type": "application/json; charset=utf-8",
                        "sec-fetch-dest": "empty",
                        "sec-fetch-mode": "cors",
                        "sec-fetch-site": "same-site"
                    },
                    "referrer": "https://www.parfumdreams.de/User/Addresses",
                    "referrerPolicy": "no-referrer-when-downgrade",
                    "body": `${JSON.stringify(body)}`,
                    "method": "POST",
                    "mode": "cors",
                    "credentials": "include"
                }).then(res => {
                    return res.json();
                }).then(data => {
                    console.log(data);
                    prepareCheckout();
                }).catch(error => {
                    console.log(error);
                    try {
                        iziToast.error({
                            title: error.message
                        });
                    } catch {}
                });
            }

            function prepareCheckout() {

                var coupons = a.coupons.split('\n');
                console.log(coupons);

                if (coupons.length == 1 && coupons[0] === '') { //no coupons left
                    try {
                        iziToast.error({
                            title: "NO Coupon left!"
                        });
                    } catch {}
                    // Set Invoice ID
                    try {
                        iziToast.info({
                            title: "Setting Invoice Profile + Samples"
                        });
                    } catch {}

                    var apiOrder = JSON.parse(localStorage.ApiOrder);
                    console.log(apiOrder);

                    apiOrder.idBillingUserAddress = parseInt(invoiceID);
                    apiOrder.useFreeSamples = true;
                    apiOrder = JSON.stringify(apiOrder);

                    localStorage.setItem('ApiOrder', apiOrder);
                    console.log(JSON.parse(localStorage.ApiOrder));

                    window.location.replace(`https://www.parfumdreams.de/Order/Payment`);
                } else {
                    var firstCoupon = coupons[0];

                    // Check Coupon
                    try {
                        iziToast.info({
                            title: "Checking Coupon"
                        });
                    } catch {}

                    var body = {
                        order: JSON.parse(localStorage.ApiOrder),
                        userId: user.userId
                    }

                    fetch(`https://shop-api.parfumdreams.de/api/DE/Order/AddCoupon?couponCode=${firstCoupon}`, {
                        "headers": {
                            "accept": "*/*",
                            "accept-language": "de,en-US;q=0.9,en;q=0.8,de-DE;q=0.7",
                            "api-client-app-ctx.is-apple": "False",
                            "api-client-app-ctx.remote-ip-address": "10.15.0.252",
                            "api-client-app-ctx.view-mode": "1",
                            "api-key": "",
                            "authorization": `Bearer ${user.accessToken}`,
                            "content-type": "application/json; charset=utf-8",
                            "sec-ch-ua": "\"Google Chrome\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"",
                            "sec-ch-ua-mobile": "?0",
                            "sec-ch-ua-platform": "\"Windows\"",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-site"
                        },
                        "referrer": "https://www.parfumdreams.de/Order",
                        "referrerPolicy": "no-referrer-when-downgrade",
                        "body": JSON.stringify(body),
                        "method": "POST",
                        "mode": "cors",
                        "credentials": "include"
                    }).then(res => {
                        return res.json();
                    }).then(data => {
                        console.log(data);

                        if (data.hints[0].text.includes("erfolgreich")) {
                            if (coupons.length == 1) {
                                try {
                                    iziToast.warning({
                                        title: "LAST Coupon:",
                                        message: `${firstCoupon}`
                                    });
                                } catch {}
                            }

                            // Set Invoice ID
                            try {
                                iziToast.info({
                                    title: "Setting Invoice Profile + Samples"
                                });
                            } catch {}

                            var apiOrder = JSON.parse(localStorage.ApiOrder);
                            console.log(apiOrder);

                            apiOrder.idBillingUserAddress = parseInt(invoiceID);
                            apiOrder.useFreeSamples = true;
                            apiOrder.pendingCouponCode = firstCoupon;
                            apiOrder = JSON.stringify(apiOrder);

                            localStorage.setItem('ApiOrder', apiOrder);
                            console.log(JSON.parse(localStorage.ApiOrder));

                            try {
                                iziToast.success({
                                    title: "Coupon Applied!"
                                });
                            } catch {}

                            //Remove Coupon from List
                            console.log(a.coupons);
                            coupons = coupons.slice(1);

                            var newCoupons = coupons.join('\n');
                            console.log(newCoupons);

                            chrome.storage.local.set({
                                coupons: newCoupons
                            });

                            window.location.replace(`https://www.parfumdreams.de/Order/Payment`);

                        } else {
                            try {
                                iziToast.error({
                                    title: "Coupon not working.",
                                    message: data.hints[0].text
                                });
                            } catch {}

                            // Set Invoice ID
                            try {
                                iziToast.info({
                                    title: "Setting Invoice Profile + Samples"
                                });
                            } catch {}

                            var apiOrder = JSON.parse(localStorage.ApiOrder);
                            console.log(apiOrder);

                            apiOrder.idBillingUserAddress = parseInt(invoiceID);
                            apiOrder.useFreeSamples = true;
                            apiOrder = JSON.stringify(apiOrder);

                            localStorage.setItem('ApiOrder', apiOrder);
                            console.log(JSON.parse(localStorage.ApiOrder));

                            window.location.replace(`https://www.parfumdreams.de/Order/Payment`);
                        }
                    });
                }
            }
        }
    });
}