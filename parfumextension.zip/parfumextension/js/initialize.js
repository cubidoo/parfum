var url = document.location;

if (url.origin.includes("parfumdreams") && url.href.includes("/User/Addresses") && url.search.includes("initialize=true")) {

    chrome.storage.local.get("valid", (z) => {
        if (z.valid) {
            console.log("Logged in!");

            //wait for document load
            if (document.readyState !== 'loading') {
                initialize();
            } else {
                document.addEventListener('DOMContentLoaded', function () {
                    initialize();
                });
            }

            var invoices = [{
                    firstname: "Anschrift -L-Age",
                    lastname: "eCom. GmbH",
                    street: "Zu Am Steine-kreuz",
                    housenumber: "24",
                    street2: "",
                    plz: "66802",
                    city: "Bisten, Überherrn"
                },
                {
                    firstname: "zu Adresse -L-Age",
                    lastname: "eComm. GmbH",
                    street: "Anschrift Am Steine kreuz 24",
                    housenumber: "24",
                    street2: "",
                    plz: "66802",
                    city: "Ot Bisten"
                },
                {
                    firstname: "Leonard und",
                    lastname: "Laurence Hesslinger",
                    street: "Straße Am-Steine-kreuz",
                    housenumber: "24",
                    street2: "c/0 L-AGE eCommerce-Gmbh",
                    plz: "66802",
                    city: "Überherrn"
                },
                {
                    firstname: "Leonard",
                    lastname: "Hesslinger",
                    street: "Amm Steinekreuz-",
                    housenumber: "24",
                    street2: "L-AGE eComm. GmbH",
                    plz: "66802",
                    city: "Ueberherrn, Bisten"
                },
                {
                    firstname: "Laurence",
                    lastname: "Heßlinger",
                    street: "Street Am Steine kreuz",
                    housenumber: "24",
                    street2: "-L AGE eCommer. GmbH",
                    plz: "66802",
                    city: "Uberherrn"
                }
            ];

            var invoiceProfiles = [];

            function initialize() {
                var count = 0;
                var user = JSON.parse(localStorage.User);

                try {
                    iziToast.info({
                        title: "Scraping all Profiles."
                    });
                } catch {}
                getAllAddresses();

                // Get All Addresses
                function getAllAddresses() {
                    fetch(`https://shop-api.parfumdreams.de/api/DE/user/getalladdresses?userId=${user.userId}`, {
                        "headers": {
                            "accept": "*/*",
                            "accept-language": "de,en-US;q=0.9,en;q=0.8,de-DE;q=0.7",
                            "api-client-app-ctx.is-apple": "False",
                            "api-client-app-ctx.remote-ip-address": "10.15.0.252",
                            "api-client-app-ctx.view-mode": "1",
                            "api-key": "",
                            "authorization": `Bearer ${user.accessToken}`,
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-site"
                        },
                        "referrer": "https://www.parfumdreams.de/User/Addresses",
                        "referrerPolicy": "no-referrer-when-downgrade",
                        "body": null,
                        "method": "GET",
                        "mode": "cors",
                        "credentials": "include"
                    }).then(res => {
                        return res.json();
                    }).then(async data => {
                        console.log(data.result);

                        deleteAddress(data.result.addresses);

                        //createDummyProfile();
                    });
                }

                // Delete All Addresses
                function deleteAddress(addresses) {
                    if (addresses.length == 0) createDummyProfile();
                    else {
                        console.log("Deleting Address: " + addresses[count].id);

                        fetch(`https://shop-api.parfumdreams.de/api/DE/user/removeaddress?userId=${user.userId}`, {
                            "headers": {
                                "accept": "*/*",
                                "accept-language": "de,en-US;q=0.9,en;q=0.8,de-DE;q=0.7",
                                "api-client-app-ctx.is-apple": "False",
                                "api-client-app-ctx.remote-ip-address": "10.15.0.252",
                                "api-client-app-ctx.view-mode": "1",
                                "api-key": "",
                                "authorization": `Bearer ${user.accessToken}`,
                                "content-type": "application/json; charset=utf-8",
                                "sec-fetch-dest": "empty",
                                "sec-fetch-mode": "cors",
                                "sec-fetch-site": "same-site"
                            },
                            "referrer": "https://www.parfumdreams.de/User/Addresses",
                            "referrerPolicy": "no-referrer-when-downgrade",
                            "body": `{\n  \"id\": ${addresses[count].id}\n}`,
                            "method": "POST",
                            "mode": "cors",
                            "credentials": "include"
                        }).then(res => {
                            return res.json();
                        }).then(data => {
                            console.log("Deleted Address: " + addresses[count].id);
                            console.log(data.result);

                            if (count < addresses.length - 1) {
                                // Remove next address
                                count++;
                                deleteAddress(addresses);
                            } else {
                                // Done
                                try {
                                    iziToast.info({
                                        title: "Deleted all Profiles."
                                    });
                                } catch {}
                                count = 0;
                                createDummyProfile();
                            }
                        });
                    }
                }

                // Create Dummy Profile
                function createDummyProfile() {

                    var body = {
                        "address": {
                            "$type": "DefaultAddressViewModel",
                            "addition": "Addy Zusatz",
                            "street": "Spinozastraße",
                            "houseNumberIsRequired": true,
                            "houseNumber": "24",
                            "type": 1,
                            "streetAndHouseNumber": "Spinozastraße 24",
                            "compactFormat": "Max Mustermann\nSpinozastraße 24, 45279 Essen, de",
                            "name": "Mustermann",
                            "forenameIsRequired": true,
                            "forename": "Max",
                            "postCode": "45279",
                            "city": "Essen",
                            "countryToken": "de",
                            "country": "Deutschland",
                            "phone": "017671627381",
                            "isDefaultShippingAddress": true
                        }
                    }

                    fetch(`https://shop-api.parfumdreams.de/api/DE/user/addaddress?userId=${user.userId}`, {
                        "headers": {
                            "accept": "*/*",
                            "accept-language": "de,en-US;q=0.9,en;q=0.8,de-DE;q=0.7",
                            "api-client-app-ctx.is-apple": "False",
                            "api-client-app-ctx.remote-ip-address": "10.15.0.252",
                            "api-client-app-ctx.view-mode": "1",
                            "api-key": "",
                            "authorization": `Bearer ${user.accessToken}`,
                            "content-type": "application/json; charset=utf-8",
                            "priority": "u=1, i",
                            "sec-ch-ua": "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Google Chrome\";v=\"126\"",
                            "sec-ch-ua-mobile": "?0",
                            "sec-ch-ua-platform": "\"Windows\"",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-site"
                        },
                        "referrer": "https://www.parfumdreams.de/User/Addresses",
                        "referrerPolicy": "no-referrer-when-downgrade",
                        "body": JSON.stringify(body),
                        "method": "POST",
                        "mode": "cors",
                        "credentials": "include"
                    }).then(res => {
                        return res.json();
                    }).then(data => {
                        console.log(data);
                        try {
                            iziToast.info({
                                title: "Created Dummy Profile."
                            });
                        } catch {}

                        chrome.storage.local.set({
                            dummyProfile: data.result
                        });

                        createInvoiceProfile();
                    });
                }

                // Create Invoice Profiles
                function createInvoiceProfile() {
                    var body = {
                        "address": {
                            "$type": "DefaultAddressViewModel",
                            "addition": `${invoices[count].street2}`,
                            "street": `${invoices[count].street}`,
                            "houseNumberIsRequired": true,
                            "houseNumber": `${invoices[count].housenumber}`,
                            "type": 1,
                            "streetAndHouseNumber": `${invoices[count].street} ${invoices[count].housenumber}`,
                            "compactFormat": `${invoices[count].firstname} ${invoices[count].lastname}\n${invoices[count].street} ${invoices[count].housenumber}, ${invoices[count].plz} ${invoices[count].city}, de`,
                            "name": `${invoices[count].lastname}`,
                            "forenameIsRequired": true,
                            "forename": `${invoices[count].firstname}`,
                            "postCode": `${invoices[count].plz}`,
                            "city": `${invoices[count].city}`,
                            "countryToken": "de",
                            "country": "Deutschland",
                            "phone": "",
                            "isDefaultBillingAddress": true
                        }
                    }

                    fetch(`https://shop-api.parfumdreams.de/api/DE/user/addaddress?userId=${user.userId}`, {
                        "headers": {
                            "accept": "*/*",
                            "accept-language": "de,en-US;q=0.9,en;q=0.8,de-DE;q=0.7",
                            "api-client-app-ctx.is-apple": "False",
                            "api-client-app-ctx.remote-ip-address": "10.15.0.252",
                            "api-client-app-ctx.view-mode": "1",
                            "api-key": "",
                            "authorization": `Bearer ${user.accessToken}`,
                            "content-type": "application/json; charset=utf-8",
                            "priority": "u=1, i",
                            "sec-ch-ua": "\"Not/A)Brand\";v=\"8\", \"Chromium\";v=\"126\", \"Google Chrome\";v=\"126\"",
                            "sec-ch-ua-mobile": "?0",
                            "sec-ch-ua-platform": "\"Windows\"",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-site"
                        },
                        "referrer": "https://www.parfumdreams.de/User/Addresses",
                        "referrerPolicy": "no-referrer-when-downgrade",
                        "body": JSON.stringify(body),
                        "method": "POST",
                        "mode": "cors",
                        "credentials": "include"
                    }).then(res => {
                        return res.json();
                    }).then(data => {
                        console.log(body);
                        console.log(data);
                        invoiceProfiles.push(data.result);
                        console.log("Created Invoice Profile. " + `${count+1}/${invoices.length}`);
                        try {
                            iziToast.info({
                                title: "Created Invoice Profile. " + `${count+1}/${invoices.length}`
                            });
                        } catch {}

                        if (count == 4) {
                            chrome.storage.local.set({
                                invoiceProfiles: invoiceProfiles
                            });

                            try {
                                iziToast.info({
                                    title: "Done"
                                });
                            } catch {}

                            //window.close();
                        } else {
                            count++;
                            createInvoiceProfile();
                        }
                    });
                }
            }
        }
    });
}