var url = document.location;

if (url.origin.includes("parfumdreams") && url.href.includes("/User/Details") && url.search.includes("initialize=true")) {

    chrome.storage.local.get("valid", (z) => {
        if (z.valid) {
            console.log("Logged in!");
            
            //wait for document load
            if (document.readyState !== 'loading') {
                start();
            } else {
                document.addEventListener('DOMContentLoaded', function () {
                    start();
                });
            }

            function start() {
                if (document.querySelector('[action="/User/AddressList"]')) { //already loaded
                    console.log("Initializing.");

                    initialize();
                } else {
                    //wait for email to load
                    const fe = new MutationObserver(mutations => {
                        if (document.querySelector('[action="/User/AddressList"]')) {
                            console.log("Initializing.");
                            initialize();
                            fe.disconnect();
                        }
                    });
                    fe.observe(document.body, {
                        childList: true,
                        subtree: true
                    });
                }
            }

            var invoices = [
                {
                    firstname: "Anschrift: L-AGE",
                    lastname: "eCom. GmbH",
                    street: "Zu: Am Steine-kreuz",
                    housenumber: "24",
                    street2: "",
                    plz: "66802",
                    city: "Bisten, Überherrn"
                },
                {
                    firstname: "Zu Adresse: L-AGE",
                    lastname: "eComm. GmbH",
                    street: "Anschrift: Am Steine_kreuz",
                    housenumber: "24",
                    street2: "",
                    plz: "66802",
                    city: "OT Bisten"
                },
                {
                    firstname: "An Firm: L_AGe",
                    lastname: "eComm. GmbH",
                    street: "Straße: Am-Steine-kreuz",
                    housenumber: "24",
                    street2: "",
                    plz: "66802",
                    city: "Überherrn"
                },
                {
                    firstname: "Leonard",
                    lastname: "Hesslinger",
                    street: "Amm STeinekreuz",
                    housenumber: "24",
                    street2: "L-AGE eComm. GmbH",
                    plz: "66802",
                    city: "Überherrn, Bisten"
                },
                {
                    firstname: "Laurence",
                    lastname: "Heßlinger",
                    street: "Straße: Am Steine kreuz",
                    housenumber: "24",
                    street2: "L-AGE ecommer. GmbH",
                    plz: "66802",
                    city: "Überherrn"
                }
            ];

            var invoiceIDs = [];

            function initialize() {
                var count = 0;
                var forms = document.querySelectorAll('[action="/User/AddressList"]');
                //Delete all Profiles
                console.log(`Deleting ${forms.length} Profiles`);
                try {
                    iziToast.info({
                        title: `Deleting ${forms.length} Profiles`
                    });
                } catch {}

                if (forms.length == 0) createClient();
                for (var i = 0; i < forms.length; i++) {
                    removeProfile(forms[i].querySelector('[name="addressId"]').value);
                }

                function removeProfile(id) {
                    console.log(`Removing ${id}`);

                    fetch(`${url.origin}/User/AddressListAjax`, {
                        "headers": {
                            "accept": "*/*",
                            "accept-language": "de,en-US;q=0.9,en;q=0.8,de-DE;q=0.7",
                            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-origin",
                            "x-requested-with": "XMLHttpRequest"
                        },
                        "referrer": "https://www.parfumdreams.de/User/Details",
                        "referrerPolicy": "no-referrer-when-downgrade",
                        "body": `wt_form=1&addressId=${id}&submitButtonAction=Delete`,
                        "method": "POST",
                        "mode": "cors",
                        "credentials": "include"
                    }).then(res => {
                        console.log(res);
                        count++;
                        console.log(count);

                        if (count == forms.length) createClient();
                    }).catch(error => {
                        console.log(error);
                        try {
                            iziToast.error({
                                title: error.message
                            });
                        } catch {}
                    });
                }

                function createClient() {
                    console.log("Creating Client Profile");
                    try {
                        iziToast.info({
                            title: "Creating Client Dummy Profile"
                        });
                    } catch {}

                    fetch(`${url.origin}/User/AddressEditAjax`, {
                        "headers": {
                            "accept": "*/*",
                            "accept-language": "de,en-US;q=0.9,en;q=0.8,de-DE;q=0.7",
                            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-origin",
                            "x-requested-with": "XMLHttpRequest"
                        },
                        "referrer": `${url.origin}/User/Details`,
                        "referrerPolicy": "no-referrer-when-downgrade",
                        "body": `wt_form=1&ActionButtonsStyle=True&Id=0&ValidateStringLength=False&IsGuestAddress=False&IsOnePageAnonymousUser=False&EmailIsRequired=False&IsShippingAddress=False&Description=&Forename=Max&ForenameEnabled=True&Name=Mustermann&Street=Musterstrasse&AddressType=Default&HouseNumber=14&HouseNumberEnabled=True&Addition=&PostCode=45279&PostCodeRequired=True&PostCodeRegularExpression=%5E%5B0-9%5D%7B5%7D%24&City=Essen&Country=de&submitButtonAction=Add`,
                        "method": "POST",
                        "mode": "cors",
                        "credentials": "include"
                    }).then(res => {
                        console.log(res);

                        return res.text();
                    }).then(data => {
                        // Convert the HTML string into a document object
                        var parser = new DOMParser();
                        var doc = parser.parseFromString(data, 'text/html');

                        console.log(doc);

                        var newForm = doc.querySelectorAll('[action="/User/AddressList"]');
                        console.log(newForm);

                        var clientID = newForm[0].querySelector('[name="addressId"]').value;
                        console.log(`Client ID: ` + clientID);
                        chrome.storage.local.set({
                            clientID: clientID
                        });

                        count = 0;
                        createInvoice(invoices[0]);
                    }).catch(error => {
                        console.log(error);
                        try {
                            iziToast.error({
                                title: error.message
                            });
                        } catch {}
                    });
                }

                function createInvoice(invoice) {
                    console.log(`Creating Invoice Profile Nr. ${count}`);
                    console.log(invoice);
                    try {
                        iziToast.info({
                            title: `Creating Invoice Profile Nr. ${count}`
                        });
                    } catch {}

                    fetch(`${url.origin}/User/AddressEditAjax`, {
                        "headers": {
                            "accept": "*/*",
                            "accept-language": "de,en-US;q=0.9,en;q=0.8,de-DE;q=0.7",
                            "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-origin",
                            "x-requested-with": "XMLHttpRequest"
                        },
                        "referrer": `${url.origin}/User/Details`,
                        "referrerPolicy": "no-referrer-when-downgrade",
                        "body": `wt_form=1&ActionButtonsStyle=True&Id=0&ValidateStringLength=False&IsGuestAddress=False&IsOnePageAnonymousUser=False&EmailIsRequired=False&IsShippingAddress=False&Description=&Forename=${encodeURIComponent(invoice.firstname)}&ForenameEnabled=True&Name=${encodeURIComponent(invoice.lastname)}&Street=${encodeURIComponent(invoice.street)}&AddressType=Default&HouseNumber=${encodeURIComponent(invoice.housenumber)}&HouseNumberEnabled=True&Addition=${encodeURIComponent(invoice.street2)}&PostCode=${encodeURIComponent(invoice.plz)}&PostCodeRequired=True&PostCodeRegularExpression=%5E%5B0-9%5D%7B5%7D%24&City=${encodeURIComponent(invoice.city)}&Country=de&submitButtonAction=Add`,
                        "method": "POST",
                        "mode": "cors",
                        "credentials": "include"
                    }).then(res => {
                        console.log(res);

                        return res.text();
                    }).then(data => {
                        // Convert the HTML string into a document object
                        var parser = new DOMParser();
                        var doc = parser.parseFromString(data, 'text/html');

                        console.log(doc);

                        var newForm = doc.querySelectorAll('[action="/User/AddressList"]');
                        console.log(newForm);

                        var invoiceID = newForm[count+1].querySelector('[name="addressId"]').value;
                        console.log("Invoice ID: " + invoiceID);
                        invoiceIDs.push(invoiceID);

                        count++;
                        if (count == 5) {
                            try {
                                iziToast.success({
                                    title: "Created Invoice Profiles!"
                                });
                            } catch {}
                            console.log(invoiceIDs);
                            chrome.storage.local.set({
                                invoiceIDs: invoiceIDs
                            });
                        } else {
                            //next invoice
                            createInvoice(invoices[count]);
                        }

                    }).catch(error => {
                        console.log(error);
                        try {
                            iziToast.error({
                                title: error.message
                            });
                        } catch {}
                    });
                }
            }
        }
    });
}