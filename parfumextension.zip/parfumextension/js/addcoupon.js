var url = document.location;

if (url.origin.includes("parfumdreams") && url.href.includes("?addcoupon")) {
    chrome.storage.local.get([
        "valid",
        "dummyProfile",
        "invoiceProfiles",
        "coupons"
    ], (a) => {
        if (a.valid) {
            var params = new URLSearchParams(url.search);
            console.log(params);

            var billing = params.get("billing");

            console.log(document.cookie.split("; "));

            var coupons = a.coupons.split('\n');
            console.log(coupons);

            //wait for document load
            if (document.readyState !== 'loading') {
                start();
            } else {
                document.addEventListener('DOMContentLoaded', function () {
                    start();
                });
            }

            function start() {
                var cookies = document.cookie.split(";");
                var user;

                cookies.forEach((cookie) => {
                    if (cookie.includes("ApiUser")) {
                        user = JSON.parse(decodeURIComponent(cookie.split("=")[1]))
                    }
                });

                if (coupons.length == 1 && coupons[0] === '') { //no coupons left
                    console.log("No Coupons.")
                    try {
                        iziToast.error({
                            title: "NO Coupon left!"
                        });
                    } catch {}
                    // Set Invoice ID
                    try {
                        iziToast.info({
                            title: "Setting Invoice Profile + Samples"
                        });
                    } catch {}

                    var apiOrder = document.cookie.split("; ");
                    for (var i = 0; i < apiOrder.length; i++) {
                        if (apiOrder[i].startsWith("ApiOrder")) apiOrder = apiOrder[i];
                    }
                    console.log(apiOrder.split("=")[1]);
                    apiOrder = JSON.parse(decodeURIComponent(apiOrder.split("=")[1]));

                    apiOrder.idBillingUserAddress = parseInt(billing);
                    apiOrder.useFreeSamples = true;

                    apiOrder = encodeURIComponent(JSON.stringify(apiOrder));
                    console.log(apiOrder);

                    document.cookie = `ApiOrder=${apiOrder}`;

                    window.location.replace(`https://www.parfumdreams.de/Order/Payment`);
                } else {
                    var firstCoupon = coupons[0];

                    console.log(document.cookie.split("; "));
                    var apiOrderBody = document.cookie.split("; ");
                    for (var i = 0; i < apiOrderBody.length; i++) {
                        if (apiOrderBody[i].startsWith("ApiOrder")) apiOrderBody = apiOrderBody[i];
                    }
                    apiOrderBody = JSON.parse(decodeURIComponent(apiOrderBody.split("=")[1]));

                    // Check Coupon
                    try {
                        iziToast.info({
                            title: "Checking Coupon"
                        });
                    } catch {}

                    var body = {
                        order: apiOrderBody,
                        userId: user.userId
                    }

                    fetch(`https://shop-api.parfumdreams.de/api/DE/Order/AddCoupon?couponCode=${firstCoupon}`, {
                        "headers": {
                            "accept": "*/*",
                            "accept-language": "de,en-US;q=0.9,en;q=0.8,de-DE;q=0.7",
                            "api-client-app-ctx.is-apple": "False",
                            "api-client-app-ctx.remote-ip-address": "10.15.0.252",
                            "api-client-app-ctx.view-mode": "1",
                            "api-key": "",
                            "authorization": `Bearer ${user.accessToken}`,
                            "content-type": "application/json; charset=utf-8",
                            "sec-ch-ua": "\"Google Chrome\";v=\"123\", \"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"123\"",
                            "sec-ch-ua-mobile": "?0",
                            "sec-ch-ua-platform": "\"Windows\"",
                            "sec-fetch-dest": "empty",
                            "sec-fetch-mode": "cors",
                            "sec-fetch-site": "same-site"
                        },
                        "referrer": "https://www.parfumdreams.de/Order",
                        "referrerPolicy": "no-referrer-when-downgrade",
                        "body": JSON.stringify(body),
                        "method": "POST",
                        "mode": "cors",
                        "credentials": "include"
                    }).then(res => {
                        return res.json();
                    }).then(data => {
                        console.log(data);
                        console.log(document.cookie.split("; "));

                        if (data.hints[0].text.includes("erfolgreich")) {
                            if (coupons.length == 1) {
                                console.log("Using last Coupon.")
                                try {
                                    iziToast.warning({
                                        title: "LAST Coupon:",
                                        message: `${firstCoupon}`
                                    });
                                } catch {}
                            }

                            // Set Invoice ID
                            try {
                                iziToast.info({
                                    title: "Setting Invoice Profile + Samples"
                                });
                            } catch {}

                            var apiOrder = document.cookie.split("; ");
                            for (var i = 0; i < apiOrder.length; i++) {
                                if (apiOrder[i].startsWith("ApiOrder")) apiOrder = apiOrder[i];
                            }
                            console.log(apiOrder.split("=")[1]);
                            apiOrder = JSON.parse(decodeURIComponent(apiOrder.split("=")[1]));

                            apiOrder.idBillingUserAddress = parseInt(billing);
                            apiOrder.useFreeSamples = true;
                            apiOrder.pendingCouponCode = firstCoupon;

                            apiOrder = encodeURIComponent(JSON.stringify(apiOrder));
                            console.log(apiOrder);

                            document.cookie = `ApiOrder=${apiOrder}`;
                            console.log(document.cookie.split("; "));

                            try {
                                iziToast.success({
                                    title: "Coupon Applied!"
                                });
                            } catch {}

                            //Remove Coupon from List
                            console.log(a.coupons);
                            coupons = coupons.slice(1);

                            var newCoupons = coupons.join('\n');
                            console.log(newCoupons);

                            chrome.storage.local.set({
                                coupons: newCoupons
                            });

                            window.location.replace(`https://www.parfumdreams.de/Order/Payment`);

                        } else {
                            console.log("Coupon not working");
                            try {
                                iziToast.error({
                                    title: "Coupon not working.",
                                    message: data.hints[0].text
                                });
                            } catch {}

                            // Set Invoice ID
                            try {
                                iziToast.info({
                                    title: "Setting Invoice Profile + Samples"
                                });
                            } catch {}

                            var apiOrder = document.cookie.split("; ");
                            for (var i = 0; i < apiOrder.length; i++) {
                                if (apiOrder[i].startsWith("ApiOrder")) apiOrder = apiOrder[i];
                            }
                            console.log(apiOrder.split("=")[1]);
                            apiOrder = JSON.parse(decodeURIComponent(apiOrder.split("=")[1]));

                            apiOrder.idBillingUserAddress = parseInt(billing);
                            apiOrder.useFreeSamples = true;

                            apiOrder = encodeURIComponent(JSON.stringify(apiOrder));
                            console.log(apiOrder);

                            document.cookie = `ApiOrder=${apiOrder}`;

                            window.location.replace(`https://www.parfumdreams.de/Order/Payment`);
                        }
                    });
                }
            }
        }
    });
}