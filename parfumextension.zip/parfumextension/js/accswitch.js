var url = document.location;

if (url.origin.includes("parfumdreams") && url.search.includes("switchacc=true")) {
    var params = new URLSearchParams(url.search);
    console.log(params);

    var email = params.get("email");
    var password = params.get("pw");

    console.log("Logging out.");

    // Delete Cookies of current Website
    chrome.runtime.sendMessage({
        message: 'deleteCookies'
    }, function (response) {
        console.log(response);

        if (response === "success") {
            console.log("Deleting all Data");
            console.log(localStorage);
            // Delete LocalStorage
            localStorage.clear();

            // Delete SessionStorage
            sessionStorage.clear();

            console.log(localStorage);

            // Login into new Account
            fetch("https://shop-api.parfumdreams.de/api/DE/login/login", {
                "headers": {
                    "accept": "*/*",
                    "accept-language": "de,en-US;q=0.9,en;q=0.8,de-DE;q=0.7",
                    "api-client-app-ctx.is-apple": "False",
                    "api-client-app-ctx.remote-ip-address": "10.15.0.252",
                    "api-client-app-ctx.view-mode": "1",
                    "api-key": "",
                    "content-type": "application/json; charset=utf-8",
                    "sec-fetch-dest": "empty",
                    "sec-fetch-mode": "cors",
                    "sec-fetch-site": "same-site"
                },
                "referrer": "https://www.parfumdreams.de/User/Login",
                "referrerPolicy": "no-referrer-when-downgrade",
                "body": `{\n  \"email\": \"${email}\",\n  \"password\": \"${password}\"\n}`,
                "method": "POST",
                "mode": "cors",
                "credentials": "omit"
            }).then(res => {
                return res.json();
            }).then(data => {
                console.log(data);
                if (data.hints.length == 0) {
                    //window.close();
                } else {
                    try {
                        iziToast.error({
                            title: "Login failed. Please login manually."
                        });
                    } catch {}
                }
            });
        }
    });
};