var url = document.location;

if (url.origin.includes("sellercentral.amazon") && url.href.includes("/order/")) {
//if (url.href.includes('amazon/street.mhtml')) {
    chrome.storage.local.get("valid", (z) => {
        if (z.valid) {
            console.log("Logged in!");

            //wait for document load
            if (document.readyState !== 'loading') {
                start();
            } else {
                document.addEventListener('DOMContentLoaded', function () {
                    start();
                });
            }

            function start() {
                if (document.querySelector('[data-test-id="shipping-section-buyer-address"]') && document.querySelector('[class="product-name-column-word-wrap-break-all"]')) { //already loaded
                    check();
                } else {
                    //wait for email to load
                    const fe = new MutationObserver(mutations => {
                        if (document.querySelector('[data-test-id="shipping-section-buyer-address"]') && document.querySelector('[class="product-name-column-word-wrap-break-all"]')) {
                            check();
                            fe.disconnect();
                        }
                    });
                    fe.observe(document.body, {
                        childList: true,
                        subtree: true
                    });
                }
            }

            function check() {
                try {
                    chrome.storage.local.get("products", (a) => {
                        if (a.products != undefined) {
                            var products = a.products;
                            console.log(products);

                            var asin = document.querySelector('[class="product-name-column-word-wrap-break-all"]').getElementsByTagName('b')[0].innerHTML;
                            console.log(asin);

                            //check if asin is in productslist
                            for (var i = 0; i < products.length; i++) {
                                var product = products[i];

                                var productlink = product.link;
                                console.log(productlink);
                                if (productlink.includes("?")) {
                                    productlink = productlink.substring(0, productlink.indexOf("?"));
                                }
                                console.log(productlink);

                                if (products[i].asin === asin) {
                                    console.log(products[i]);

                                    document.querySelector('[data-test-id="shipping-section-buyer-po"]').appendChild(document.createElement('p'));
                                    document.querySelector('[data-test-id="shipping-section-buyer-po"]').appendChild(document.querySelector('[data-test-id="shipping-section-buyer-address"]').cloneNode(true));
                                    var address = document.querySelector('[data-test-id="shipping-section-buyer-address"]').getElementsByTagName('span');

                                    //remove space span
                                    for (var i = 0; i < address.length; i++) {
                                        if (address[i].innerHTML === '&nbsp;') {
                                            address[i].parentNode.removeChild(address[i]);
                                        }
                                    }
                                    //remove country
                                    address[address.length - 1].parentNode.removeChild(address[address.length - 1]);

                                    var fullname;
                                    var fullstreet;

                                    var addressjson = {
                                        firstname: "",
                                        lastname: "",
                                        street: "",
                                        housenumber: "",
                                        street2: "",
                                        plz: "",
                                        city: "",
                                    }

                                    //no street2 + no state = 4
                                    //no street2 + state = 5
                                    //street2 + no state = 5
                                    //street2 + state = 6

                                    //get all infos in array
                                    console.log(address);

                                    var linebreaks = [];
                                    var nolinebreaks = [];
                                    for (var j = 0; j < address.length; j++) {
                                        console.log(address[j].innerText);

                                        if (address[j].innerText.includes('\n')) {

                                            address[j].innerText = address[j].innerText.replace('\n', "");
                                            linebreaks.push(address[j].innerText);
                                        } else nolinebreaks.push(address[j].innerText);
                                    }
                                    console.log(linebreaks);
                                    console.log(nolinebreaks);

                                    //name
                                    fullname = linebreaks[0].split(" ");
                                    addressjson.lastname = fullname[fullname.length - 1];
                                    fullname.pop(); //remove last word
                                    addressjson.firstname = fullname.join(' ');

                                    if (linebreaks.length == 2) { //no street2

                                        fullstreet = linebreaks[1].split(" ");
                                        addressjson.housenumber = fullstreet[fullstreet.length - 1];
                                        fullstreet.pop(); //remove last word
                                        addressjson.street = fullstreet.join(' ');
                                        addressjson.street2 = " ";

                                    } else if (linebreaks.length == 3) { //street2

                                        fullstreet = linebreaks[2].split(" ");
                                        addressjson.housenumber = fullstreet[fullstreet.length - 1];
                                        fullstreet.pop(); //remove last word
                                        addressjson.street = fullstreet.join(' ');
                                        addressjson.street2 = linebreaks[1];
                                    }

                                    addressjson.plz = nolinebreaks[0];
                                    addressjson.city = nolinebreaks[1].replaceAll(",", " ").trim();

                                    console.log(addressjson);

                                    //checkout + shipping
                                    var parfumlink = document.createElement('a');
                                    parfumlink.innerHTML = " CHECKOUT + SHIPPING";
                                    parfumlink.target = '_blank';
                                    parfumlink.href = `${productlink}${jsonToQueryString(addressjson)}&checkout=true&shipping=true`;
                                    console.log(parfumlink);

                                    document.querySelector('[class="product-name-column-word-wrap-break-all"]').getElementsByTagName('b')[0].appendChild(parfumlink);
                                    document.querySelector('[class="product-name-column-word-wrap-break-all"]').getElementsByTagName('b')[0].appendChild(document.createElement('br'));

                                    //checkout + no shipping
                                    var parfumlink2 = document.createElement('a');
                                    parfumlink2.innerHTML = " CHECKOUT + NO SHIPPING";
                                    parfumlink2.target = '_blank';
                                    parfumlink2.href = `${productlink}?checkout=true&shipping=false`;
                                    console.log(parfumlink2);

                                    document.querySelector('[class="product-name-column-word-wrap-break-all"]').getElementsByTagName('b')[0].appendChild(parfumlink2);
                                    document.querySelector('[class="product-name-column-word-wrap-break-all"]').getElementsByTagName('b')[0].appendChild(document.createElement('br'));

                                    //no checkout + shipping
                                    var parfumlink3 = document.createElement('a');
                                    parfumlink3.innerHTML = " NO CHECKOUT + SHIPPING";
                                    parfumlink3.target = '_blank';
                                    parfumlink3.href = `${productlink}${jsonToQueryString(addressjson)}&checkout=false&shipping=true`;
                                    console.log(parfumlink2);

                                    document.querySelector('[class="product-name-column-word-wrap-break-all"]').getElementsByTagName('b')[0].appendChild(parfumlink3);
                                    document.querySelector('[class="product-name-column-word-wrap-break-all"]').getElementsByTagName('b')[0].appendChild(document.createElement('br'));

                                    //no checkout + no shipping
                                    var parfumlink4 = document.createElement('a');
                                    parfumlink4.innerHTML = " NO CHECKOUT + NO SHIPPING";
                                    parfumlink4.target = '_blank';
                                    parfumlink4.href = `${productlink}?checkout=false&shipping=false`;
                                    console.log(parfumlink4);

                                    document.querySelector('[class="product-name-column-word-wrap-break-all"]').getElementsByTagName('b')[0].appendChild(parfumlink4);
                                }
                            }
                        }
                    });
                } catch (error) {
                    console.log(error);
                    iziToast.error({
                        title: error.message
                    });
                }
            }

            function jsonToQueryString(json) {
                return '?' +
                    Object.keys(json).map(function (key) {
                        return encodeURIComponent(key) + '=' +
                            encodeURIComponent(json[key]);
                    }).join('&');
            }
        }
    });
}