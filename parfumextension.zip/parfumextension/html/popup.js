chrome.storage.local.get("virgin", function (a) {
    if (a.virgin == undefined) {
        while (true) {
            window.location.replace('login.html');
        }
    } else if (a.virgin === "juhu") {

    } else {
        while (true) {
            window.location.replace('login.html');
        }
    }
});

chrome.storage.local.get("again", function (a) {
    if (a.again == undefined) {
        while (true) {
            window.location.replace('login.html');
        }
    } else if (a.again === "jaha") {

    } else {
        while (true) {
            window.location.replace('login.html');
        }
    }
});

document.getElementById('initialize').addEventListener("click", () => {
    console.log("Starting Init");

    window.open(`https://www.parfumdreams.de/User/Details?initialize=true`);
});

chrome.storage.local.get("virgin", function (a) {
    if (a.virgin == undefined) {
        while (true) {
            window.location.replace('login.html');
        }
    } else if (a.virgin === "juhu") {

    } else {
        while (true) {
            window.location.replace('login.html');
        }
    }
});

chrome.storage.local.get("again", function (a) {
    if (a.again == undefined) {
        while (true) {
            window.location.replace('login.html');
        }
    } else if (a.again === "jaha") {

    } else {
        while (true) {
            window.location.replace('login.html');
        }
    }
});

chrome.storage.local.get("coupons", (a) => {
    if (a.coupons != undefined) {
        document.getElementById('coupons').value = a.coupons;
    } else {
        chrome.storage.local.set({
            coupons: ""
        });
    }
});

document.getElementById('coupons').addEventListener('change', () => {
    chrome.storage.local.set({
        coupons: document.getElementById('coupons').value
    });
});

chrome.storage.local.get("products", (a) => {
    if (a.products == undefined) {
        console.log("Products List created.");
        chrome.storage.local.set({
            products: []
        });
    } else {
        console.log(a.products);
        for (var i = 0; i<a.products.length; i++) {
            var div = document.createElement("div");
            div.className = 'product';

            var span = document.createElement('span');
            span.className = 'productasin';
            span.innerHTML = a.products[i].asin;
            div.appendChild(span);

            var deletebtn = document.createElement('button');
            deletebtn.className = 'productdeletebtn';
            deletebtn.innerHTML = 'REMOVE';
            deletebtnlistener(deletebtn, i);
            div.appendChild(deletebtn);

            document.getElementById("productsdiv").appendChild(div);
        }

        function deletebtnlistener(btn, index) {
            btn.addEventListener("click", () => {
                chrome.storage.local.get("products", (a) => {
                    var oldproducts = a.products;
                    console.log(oldproducts);

                    oldproducts.splice(index, 1);
                    console.log(oldproducts);

                    chrome.storage.local.set({
                        products: oldproducts
                    });

                    window.location.reload();
                });
            });
        }
    }
});

document.getElementById("importbtn").addEventListener("click", () => {
    document.getElementById("rightdiv1").setAttribute("hidden", true);
    document.getElementById("rightdiv2").removeAttribute("hidden");
});

document.getElementById("saveimportbtn").addEventListener("click", () => {
    var products = document.getElementById("importinput").value.split("\n");
    console.log(products);

    chrome.storage.local.get("products", (a) => {
        var oldproducts = a.products;

        for (var i = 0; i < products.length; i++) {
            var infos = products[i].split(":");
            console.log(infos);

            var asin = infos[0];
            infos.shift();
            var productlink = infos.join(':');
            

            var toadd = {
                asin: asin,
                link: productlink
            };
            console.log(toadd);
            oldproducts.push(toadd);
        }

        chrome.storage.local.set({
            products: oldproducts
        });
    });
    
    window.location.reload();
});

document.getElementById("addproduct").addEventListener("click", () => {
    var asin = document.getElementById("asininput").value;
    var productlink = document.getElementById("linkinput").value;

    chrome.storage.local.get("products", (a) => {
        console.log(a.products);
        var oldproducts = a.products;
        console.log(oldproducts);

        var addproduct = {
            asin: asin,
            link: productlink
        };

        oldproducts.push(addproduct);
        chrome.storage.local.set({
            products: oldproducts
        });

        window.location.reload();
    });
});

chrome.storage.local.get([
    "ccnumber",
    "cccvv",
    "ccmonth",
    "ccyear"
], (a) => {
    if (a.ccnumber != undefined) document.getElementById('ccnumber').value = a.ccnumber;
    if (a.cccvv != undefined) document.getElementById('cccvv').value = a.cccvv;
    if (a.ccmonth != undefined) document.getElementById('ccmonth').value = a.ccmonth;
    if (a.ccyear != undefined) document.getElementById('ccyear').value = a.ccyear;
});

document.getElementById('ccnumber').addEventListener("change", () => {
    chrome.storage.local.set({
        ccnumber: document.getElementById('ccnumber').value
    });
});
document.getElementById('cccvv').addEventListener("change", () => {
    chrome.storage.local.set({
        cccvv: document.getElementById('cccvv').value
    });
});
document.getElementById('ccmonth').addEventListener("change", () => {
    chrome.storage.local.set({
        ccmonth: document.getElementById('ccmonth').value
    });
});
document.getElementById('ccyear').addEventListener("change", () => {
    chrome.storage.local.set({
        ccyear: document.getElementById('ccyear').value
    });
});